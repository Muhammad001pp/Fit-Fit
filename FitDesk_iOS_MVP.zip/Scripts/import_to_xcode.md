
# Импорт в Xcode
1) Создайте новый проект iOS App `FitDesk` (SwiftUI, iOS 17+).
2) В Project Navigator кликните правой кнопкой по корню проекта → **Add Files to "FitDesk"...**.
3) Укажите папку `Source/` из этого архива. Поставьте галочки: **Copy items if needed**, **Add to targets: FitDesk**.
4) Запустите на симуляторе iPhone.
