
import SwiftUI

struct WorkoutsHomeView: View {
    @EnvironmentObject var store: AppStore
    @State private var showPrograms = false
    @State private var showAnalytics = false
    
    var body: some View {
        NavigationStack {
            ScrollView {
                if let program = store.activeProgram {
                    ProgramHeader(program: program).padding(.horizontal)
                    SectionHeader(title: "Следующие тренировки", trailing: Button("Аналитика") { showAnalytics = true })
                    ForEach(program.days.sorted { $0.index < $1.index }) { day in
                        WorkoutDayRow(day: day)
                    }
                } else {
                    Text("Нет активной программы. Выберите программу.").padding()
                }
                Button("ОТКРЫТЬ РАЗДЕЛ АНАЛИТИКИ") { showAnalytics = true }
                    .buttonStyle(.borderedProminent).padding()
            }
            .navigationTitle("Рабочий стол")
            .toolbar {
                ToolbarItem(placement: .topBarTrailing) {
                    Button { showPrograms = true } label: { Image(systemName: "text.justify") }
                }
            }
            .sheet(isPresented: $showPrograms) { MyProgramsSheet() }
            .sheet(isPresented: $showAnalytics) { AnalyticsView() }
        }
    }
}

struct ProgramHeader: View {
    let program: TrainingProgram
    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            Text(program.name).font(.headline)
            Text("\(program.totalDays) тренировочных дня (\(program.daysPerWeek) тренировки в неделю)").foregroundStyle(.secondary).font(.subheadline)
            Text("Выполнено занятий: \(program.days.filter{ $0.progress==100 }.count)").font(.subheadline)
        }.padding().background(RoundedRectangle(cornerRadius: 14).fill(Color(.systemGray6)))
    }
}

struct WorkoutDayRow: View {
    @EnvironmentObject var store: AppStore
    var day: WorkoutDay
    var body: some View {
        NavigationLink {
            ExercisesListView(day: day)
        } label: {
            HStack {
                ProgressCircle(value: day.progress)
                VStack(alignment: .leading) {
                    Text("\(day.index) тренировка").font(.subheadline)
                    Text(day.title).font(.body)
                }
                Spacer(); Image(systemName: "chevron.right").foregroundStyle(.tertiary)
            }
            .padding().background(RoundedRectangle(cornerRadius: 14).fill(.background)).overlay(RoundedRectangle(cornerRadius: 14).stroke(Color(.quaternaryLabel)))
            .padding(.horizontal)
        }
    }
}

struct ProgressCircle: View { var value: Int; var body: some View { ZStack { Circle().stroke(Color(.systemGray5), lineWidth: 6); Circle().trim(from: 0, to: CGFloat(value)/100).stroke(value==100 ? .green : .orange, style: StrokeStyle(lineWidth: 6, lineCap: .round)).rotationEffect(.degrees(-90)); Text("\(value)%").font(.footnote) }.frame(width: 44, height: 44) } }

struct SectionHeader<Trailing: View>: View { let title: String; let trailing: Trailing; init(title: String, trailing: Trailing) { self.title=title; self.trailing=trailing } var body: some View { HStack { Text(title).font(.headline); Spacer(); trailing }.padding(.horizontal) } }
