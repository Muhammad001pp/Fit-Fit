
import SwiftUI

struct ExercisesListView: View {
    @EnvironmentObject var store: AppStore
    var day: WorkoutDay
    var body: some View {
        List {
            Section { } header: {
                VStack(alignment: .leading, spacing: 6) {
                    HStack { ProgressCircle(value: day.progress); Text("\(day.index) тренировка").font(.subheadline).bold() }
                    Text(day.title).font(.callout)
                }.padding(.vertical, 6)
            }
            ForEach(day.exercises, id: \.self) { exId in
                if let ex = store.exercises.first(where: { $0.id == exId }) {
                    NavigationLink(value: ex) {
                        HStack {
                            Image(systemName: ex.image ?? "dumbbell").frame(width: 28)
                            VStack(alignment:.leading) {
                                Text(ex.title)
                                Text(subtitle(for: ex)).font(.caption).foregroundStyle(.secondary)
                            }
                            Spacer()
                            Text("0%").foregroundStyle(.secondary)
                        }
                    }
                }
            }
        }
        .navigationDestination(for: Exercise.self) { ex in ExerciseDetailView(exercise: ex) }
        .navigationTitle("Упражнения")
    }
    private func subtitle(for ex: Exercise) -> String {
        if let m = ex.recommendedTimeMin { return "\(m) мин" }
        if let r = ex.recommendedReps, let w = ex.recommendedWeight { return "4x\(r)x\(Int(w)) кг" }
        return ex.type.rawValue
    }
}
