
import SwiftUI

@main
struct FitDeskApp: App {
    @StateObject private var store = AppStore()
    var body: some Scene {
        WindowGroup {
            RootTabView()
                .environmentObject(store)
        }
    }
}
