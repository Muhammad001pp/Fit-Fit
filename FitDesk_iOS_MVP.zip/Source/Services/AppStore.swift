
import Foundation
import SwiftUI

final class AppStore: ObservableObject {
    // Каталоги
    @Published var exercises: [Exercise] = []
    @Published var programs: [TrainingProgram] = []
    @Published var activeProgram: TrainingProgram? = nil
    @Published var measurements: [MeasurementEntry] = []
    @Published var heartRate: [HeartRateSample] = []
    @Published var reference: [ReferenceSection] = []
    @Published var profile: UserProfile = .init()
    
    private let fm = FileManager.default
    private var docs: URL { fm.urls(for: .documentDirectory, in: .userDomainMask)[0] }
    
    init() {
        firstRunSeedIfNeeded()
        loadAll()
    }
    
    // MARK: Persistence JSON (просто и прозрачно)
    func saveAll() {
        save(exercises, "exercises.json")
        save(programs, "programs.json")
        save(activeProgram, "activeProgram.json")
        save(measurements, "measurements.json")
        save(heartRate, "heartRate.json")
        save(reference, "reference.json")
        save(profile, "profile.json")
    }
    
    func loadAll() {
        exercises = load("exercises.json") ?? []
        programs = load("programs.json") ?? []
        activeProgram = load("activeProgram.json") ?? programs.first
        measurements = load("measurements.json") ?? []
        heartRate = load("heartRate.json") ?? []
        reference = load("reference.json") ?? []
        profile = load("profile.json") ?? .init()
    }
    
    private func path(_ name: String) -> URL { docs.appendingPathComponent(name) }
    
    private func save<T: Encodable>(_ value: T?, _ name: String) {
        guard let value else { return }
        do {
            let data = try JSONEncoder().encode(value)
            try data.write(to: path(name), options: [.atomic])
        } catch {
            print("save error", name, error)
        }
    }
    private func load<T: Decodable>(_ name: String) -> T? {
        do {
            let data = try Data(contentsOf: path(name))
            return try JSONDecoder().decode(T.self, from: data)
        } catch { return nil }
    }
    
    // MARK: - Seeding
    private func firstRunSeedIfNeeded() {
        let flag = path(".seed_done")
        if fm.fileExists(atPath: flag.path) { return }
        do {
            try fm.createDirectory(at: docs, withIntermediateDirectories: true)
        } catch {}
        // Copy seeds from bundle
        func bundleJSON(_ name: String) -> Data? {
            guard let url = Bundle.main.url(forResource: name, withExtension: "json", subdirectory: "seed") else { return nil }
            return try? Data(contentsOf: url)
        }
        let seeds = ["exercises", "programs", "reference", "measurements", "heartRate"]
        for s in seeds {
            if let data = bundleJSON(s) {
                try? data.write(to: path(f"{s}.json"))
            }
        }
        try? "ok".data(using: .utf8)?.write(to: flag)
    }
}
